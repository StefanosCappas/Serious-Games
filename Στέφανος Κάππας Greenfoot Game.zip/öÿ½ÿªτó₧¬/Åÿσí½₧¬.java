import greenfoot.*;
import java.util.Calendar;
import java.text.SimpleDateFormat;
public class Παίκτης extends Actor
{
    private static final int SPEED = 6;
    private static final int BOUNDARY = 40;
    private int speedX = SPEED;
    private int speedY = SPEED;
    private int count = 0;
    private Counter foodCounter;
    private String flag = "L";
    String t1;
    int level, t3;
    public Παίκτης()
    {
        level = 1;
    }
    public void act()
    {
        handleKeyPresses();
        boundedMove();
        getTime();
    }
    public void getTime()
    {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("ss");
        t1 = sdf.format(cal.getTime());
    }
    private void handleKeyPresses()
    {
        if (count == 0 || count == 1)
        {
            handleArrowKey("left", -SPEED, 0);
            handleArrowKey("right", SPEED, 0);
            handleArrowKey("up", 0, -SPEED);
            handleArrowKey("down", 0, SPEED);
        }
        if (count == 2 || count == 3)
        {
            handleArrowKey("left", -SPEED+1, 0);
            handleArrowKey("right", SPEED-1, 0);
            handleArrowKey("up", 0, -SPEED+1);
            handleArrowKey("down", 0, SPEED-1);
        }
        if (count == 4 || count == 5)
        {
            handleArrowKey("left", -SPEED+2, 0);
            handleArrowKey("right", SPEED-2, 0);
            handleArrowKey("up", 0, -SPEED+2);
            handleArrowKey("down", 0, SPEED-2);
        }
        if (count == 6 || count == 7)
        {
            handleArrowKey("left", -SPEED+3, 0);
            handleArrowKey("right", SPEED-3, 0);
            handleArrowKey("up", 0, -SPEED+3);
            handleArrowKey("down", 0, SPEED-3);
        }
    }
    private void handleArrowKey(String k, int sX, int sY) 
    {
        if( Greenfoot.isKeyDown(k) ) 
        {
            if (k == "left")
            {
                if (count == 0)
                    setImage("L Παίκτης κανονικού βάρους.png");
                if (count == 1)
                    setImage("L Παίκτης υπέρβαρος.png");
                if (count == 2)
                    setImage("L Παίκτης 1ου βαθμού παχυσαρκίας.png");
                if (count == 3)
                    setImage("L Παίκτης 2ου βαθμού παχυσαρκίας.png");
                if (count == 4)
                    setImage("L Παίκτης 3ου βαθμού παχυσαρκίας.png");
                if (count == 5)
                    setImage("L Παίκτης 4ου βαθμού παχυσαρκίας.png");   
                if (count == 6)
                    setImage("L Παίκτης 5ου βαθμού παχυσαρκίας.png");
                if (count == 7)
                    setImage("L Παίκτης 6ου βαθμού παχυσαρκίας.png");
                flag = "L";
            }
            if (k == "right")
            {
                if (count == 0)
                    setImage("R Παίκτης κανονικού βάρους.png");
                if (count == 1)
                    setImage("R Παίκτης υπέρβαρος.png");
                if (count == 2)
                    setImage("R Παίκτης 1ου βαθμού παχυσαρκίας.png");
                if (count == 3)
                    setImage("R Παίκτης 2ου βαθμού παχυσαρκίας.png");
                if (count == 4)
                    setImage("R Παίκτης 3ου βαθμού παχυσαρκίας.png");
                if (count == 5)
                    setImage("R Παίκτης 4ου βαθμού παχυσαρκίας.png");   
                if (count == 6)
                    setImage("R Παίκτης 5ου βαθμού παχυσαρκίας.png");
                if (count == 7)
                    setImage("R Παίκτης 6ου βαθμού παχυσαρκίας.png");
                flag = "R";
            }
            speedX = sX;
            speedY = sY;
        }
    }
    private void boundedMove() 
    {
        setLocation(getX()+speedX, getY()+speedY);
        if( isTouching(Τούβλο.class) ) 
            setLocation(getX()-speedX, getY()-speedY);
        if( isTouching(Νερό.class) ) 
        {
            int t2 = Integer.parseInt(t1);
            setLocation(getX()-(speedX/2), getY()-(speedY/2));
            if (t2 == 0)
                t3 = t2;
            if (t3 < t2)
            {
                t3 = t2;
                if (count > 0)
                    count = count - 1;
            }
        }
        if (count == 1)
        {
            if (flag == "L")
                setImage("L Παίκτης υπέρβαρος.png");
            if (flag == "R")
                setImage("R Παίκτης υπέρβαρος.png");
        }
        if (count == 2)
        {
            if (flag == "L")
                setImage("L Παίκτης 1ου βαθμού παχυσαρκίας.png");
            if (flag == "R")
                setImage("R Παίκτης 1ου βαθμού παχυσαρκίας.png");
        }
        if (count == 3)
        {
            if (flag == "L")
                setImage("L Παίκτης 2ου βαθμού παχυσαρκίας.png");
            if (flag == "R")
                setImage("R Παίκτης 2ου βαθμού παχυσαρκίας.png");
        }
        if (count == 4)
        {
            if (flag == "L")
                setImage("L Παίκτης 3ου βαθμού παχυσαρκίας.png");
            if (flag == "R")
                setImage("R Παίκτης 3ου βαθμού παχυσαρκίας.png");
        }
        if (count == 5)
        {
            if (flag == "L")
                setImage("L Παίκτης 4ου βαθμού παχυσαρκίας.png");
            if (flag == "R")
                setImage("R Παίκτης 4ου βαθμού παχυσαρκίας.png");
        }  
        if (count == 6)
        {
            if (flag == "L")
                setImage("L Παίκτης 5ου βαθμού παχυσαρκίας.png");
            if (flag == "R")
                setImage("R Παίκτης 5ου βαθμού παχυσαρκίας.png");
        }
        if (count == 7)
        {
            if (flag == "L")
                setImage("L Παίκτης 6ου βαθμού παχυσαρκίας.png");
            if (flag == "R")
                setImage("R Παίκτης 6ου βαθμού παχυσαρκίας.png");
        }
        else if ( isTouching(Στόχος.class))
        {
            if (level==1)
            {
                getWorld().removeObject(this);
                Greenfoot.setWorld(new Επίπεδο_2(this));
                level += 1;
            }
            else if (level==2)
            {
                Greenfoot.stop();           
            }
        }
        else if ( isTouching(Φαγητό.class)) 
        {
            countFood();
            count++;
            if (count == 1)
            {
                if (flag == "L")
                    setImage("L Παίκτης υπέρβαρος.png");
                if (flag == "R")
                    setImage("R Παίκτης υπέρβαρος.png");
            }
            if (count == 2)
            {
                if (flag == "L")
                    setImage("L Παίκτης 1ου βαθμού παχυσαρκίας.png");
                if (flag == "R")
                    setImage("R Παίκτης 1ου βαθμού παχυσαρκίας.png");
            }
            if (count == 3)
            {
                if (flag == "L")
                    setImage("L Παίκτης 2ου βαθμού παχυσαρκίας.png");
                if (flag == "R")
                    setImage("R Παίκτης 2ου βαθμού παχυσαρκίας.png");
            }
            if (count == 4)
            {
                if (flag == "L")
                    setImage("L Παίκτης 3ου βαθμού παχυσαρκίας.png");
                if (flag == "R")
                    setImage("R Παίκτης 3ου βαθμού παχυσαρκίας.png");
            }
            if (count == 5)
            {
                if (flag == "L")
                    setImage("L Παίκτης 4ου βαθμού παχυσαρκίας.png");
                if (flag == "R")
                    setImage("R Παίκτης 4ου βαθμού παχυσαρκίας.png");
            }  
            if (count == 6)
            {
                if (flag == "L")
                    setImage("L Παίκτης 5ου βαθμού παχυσαρκίας.png");
                if (flag == "R")
                    setImage("R Παίκτης 5ου βαθμού παχυσαρκίας.png");
            }
            if (count == 7)
            {
                if (flag == "L")
                    setImage("L Παίκτης 6ου βαθμού παχυσαρκίας.png");
                if (flag == "R")
                    setImage("R Παίκτης 6ου βαθμού παχυσαρκίας.png");
            }
            removeTouching(Φαγητό.class);
        }
        speedX = 0;
        speedY = 0;
    }
    public void countFood()
    {
        if(foodCounter == null) 
        {
            foodCounter = new Counter("Food: ");
            int x = getX();
            int y = getY() + getImage().getWidth()/2 + 8;

            getWorld().addObject(foodCounter, x, y);
        }        
        foodCounter.increment();
    }
    public int printCount()
    {
        return count;
    }
}