import greenfoot.*;
public class GameOver extends Actor
{
    public void act() 
    {
    }    
}