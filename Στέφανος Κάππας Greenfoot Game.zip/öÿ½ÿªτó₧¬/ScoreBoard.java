import greenfoot.*;
import java.util.Calendar;
public class ScoreBoard extends Actor
{
    public static final float FONT_SIZE = 40.0f;
    public static final int WIDTH = 300;
    public static final int HEIGHT = 250;
    public ScoreBoard()
    {
        this(100);
    }
    public ScoreBoard(int score)
    {
        makeImage("Έφαγες", score, "χαμπουργκερ");
    }
    private void makeImage(String title, int score, String prefix)
    {
        GreenfootImage image = new GreenfootImage(WIDTH, HEIGHT);

        image.setColor(new Color(255,255,255, 128));
        image.fillRect(0, 0, WIDTH, HEIGHT);
        image.setColor(new Color(0, 0, 0, 128));
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10);
        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.WHITE);
        image.drawString(title, 50, 80);
        image.drawString(score + "\n" + prefix, 50, 160);
        setImage(image);
    }
}