import greenfoot.*;
import java.util.Calendar;
import java.text.SimpleDateFormat;
public class Νερό extends Block
{
    private int wormsEaten;
    private int level;
    private GreenfootImage image1;
    private GreenfootImage image2;
    private GreenfootImage image3;
    private GreenfootImage image4;
    private GreenfootImage image5;
    private GreenfootImage image6;
    private GreenfootImage image7;
    private GreenfootImage image8;
    private GreenfootImage image9;
    private GreenfootImage image10;
    private GreenfootImage image11;
    private GreenfootImage image12;
    private GreenfootImage image13;
    private GreenfootImage image14;
    private GreenfootImage image15;
    private GreenfootImage image16;
    String t1, t2;
    public Νερό()
    {
        image1 = new GreenfootImage("water_0.png");
        image2 = new GreenfootImage("water_1.png");
        image3 = new GreenfootImage("water_2.png");
        image4 = new GreenfootImage("water_3.png");
        image5 = new GreenfootImage("water_4.png");
        image6 = new GreenfootImage("water_5.png");
        image7 = new GreenfootImage("water_6.png");
        image8 = new GreenfootImage("water_7.png");
        image9 = new GreenfootImage("water_8.png");
        image10 = new GreenfootImage("water_9.png");
        image11 = new GreenfootImage("water_10.png");
        image12 = new GreenfootImage("water_11.png");
        image13 = new GreenfootImage("water_12.png");
        image14 = new GreenfootImage("water_13.png");
        image15 = new GreenfootImage("water_14.png");
        image16 = new GreenfootImage("water_15.png");
        setImage(image1);
    }
    public void act() 
    {
        getTime();
        switchImage();
    }
    public void getTime()
    {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("ss");
        t1 = sdf.format(cal.getTime());
        SimpleDateFormat dfs = new SimpleDateFormat("SS");
        t2 = dfs.format(cal.getTime());
    }
    public void switchImage()
    {
        int t3 = Integer.parseInt(t1);
        int t4 = Integer.parseInt(t2);
        t4 = t4 / 100;
        int t5 = 10*t3 + t4;
        if ( t5 % 16 == 0 )
            setImage(image1);
        else if ( t5 % 16 == 1 )
            setImage(image2);     
        else if ( t5 % 16 == 2 )
            setImage(image3);
        else if ( t5 % 16 == 3 )
            setImage(image4);
        else if ( t5 % 16 == 4 )
            setImage(image5);
        else if ( t5 % 16 == 5 )
            setImage(image6);
        else if ( t5 % 16 == 6 )
            setImage(image7);
        else if ( t5 % 16 == 7 )
            setImage(image8);       
        else if ( t5 % 16 == 8 )
            setImage(image9);     
        else if ( t5 % 16 == 9 )
            setImage(image10);      
        else if ( t5 % 16 == 10 )
            setImage(image11);
        else if ( t5 % 16 == 11 )
            setImage(image12);
        else if ( t5 % 16 == 12 )
            setImage(image13);
        else if ( t5 % 16 == 13 )
            setImage(image14);
        else if ( t5 % 16 == 14 )
            setImage(image15);
        else if ( t5 % 16 == 15 )
            setImage(image16);
    }
}