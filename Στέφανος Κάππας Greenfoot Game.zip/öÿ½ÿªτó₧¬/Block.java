import greenfoot.*;
import java.util.List;
import java.util.ArrayList;
public class Block extends Actor
{
    private static final int WALKING_SPEED = 5;
    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }
}