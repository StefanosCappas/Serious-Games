import greenfoot.*;
public class Επίπεδο_2 extends World
{
    int dount;
    public Επίπεδο_2(Παίκτης fat)
    {    
        super(1024, 576, 1); 
        prepare(fat);
    }
    private void prepare(Παίκτης fat)
    {
        int set = 64;
        int offset = 32;
        // Θάλασσα που υπάρχει στον κόσμο για να αδυνατίσει τον παχύσαρκο παίκτη
        Νερό νερό1 = new Νερό(); 
        Νερό νερό2 = new Νερό(); 
        Νερό νερό3 = new Νερό();
        Νερό νερό4 = new Νερό(); 
        Νερό νερό5 = new Νερό(); 
        Νερό νερό6 = new Νερό(); 
        Νερό νερό7 = new Νερό();
        Νερό νερό8 = new Νερό(); 
        Νερό νερό9 = new Νερό(); 
        Νερό νερό10 = new Νερό();
        Νερό νερό11 = new Νερό();
        Νερό νερό12 = new Νερό(); 
        Νερό νερό13 = new Νερό(); 
        Νερό νερό14 = new Νερό();       
        Νερό νερό15 = new Νερό(); 
        Νερό νερό16 = new Νερό(); 
        Νερό νερό17 = new Νερό();       
        Νερό νερό18 = new Νερό(); 
        Νερό νερό19 = new Νερό(); 
        Νερό νερό20 = new Νερό();
        Νερό νερό21 = new Νερό();
        Νερό νερό22 = new Νερό(); 
        Νερό νερό23 = new Νερό(); 
        Νερό νερό24 = new Νερό();       
        Νερό νερό25 = new Νερό(); 
        Νερό νερό26 = new Νερό(); 
        Νερό νερό27 = new Νερό();
        Νερό νερό28 = new Νερό(); 
        Νερό νερό29 = new Νερό(); 
        Νερό νερό30 = new Νερό();
        Νερό νερό31 = new Νερό();
        Νερό νερό32 = new Νερό(); 
        Νερό νερό33 = new Νερό(); 
        Νερό νερό34 = new Νερό();       
        Νερό νερό35 = new Νερό(); 
        Νερό νερό36 = new Νερό(); 
        Νερό νερό37 = new Νερό();   
        Νερό νερό38 = new Νερό(); 
        Νερό νερό39 = new Νερό(); 
        Νερό νερό40 = new Νερό();
        Νερό νερό41 = new Νερό();
        Νερό νερό42 = new Νερό(); 
        Νερό νερό43 = new Νερό(); 
        Νερό νερό44 = new Νερό();       
        Νερό νερό45 = new Νερό(); 
        Νερό νερό46 = new Νερό(); 
        Νερό νερό47 = new Νερό();   
        Νερό νερό48 = new Νερό(); 
        Νερό νερό49 = new Νερό(); 
        Νερό νερό50 = new Νερό();
        Νερό νερό51 = new Νερό();
        Νερό νερό52 = new Νερό(); 
        Νερό νερό53 = new Νερό(); 
        Νερό νερό54 = new Νερό();       
        Νερό νερό55 = new Νερό(); 
        Νερό νερό56 = new Νερό(); 
        Νερό νερό57 = new Νερό(); 
        Νερό νερό58 = new Νερό();
        Νερό νερό59 = new Νερό(); 
        Νερό νερό60 = new Νερό(); 
        Νερό νερό61 = new Νερό();       
        Νερό νερό62 = new Νερό(); 
        Νερό νερό63 = new Νερό(); 
        Νερό νερό64 = new Νερό(); 
        addObject(νερό1, 6*set+offset, 0*set+offset);
        addObject(νερό2, 6*set+offset, 1*set+offset);
        addObject(νερό3, 6*set+offset, 2*set+offset);
        addObject(νερό4, 6*set+offset, 3*set+offset);
        addObject(νερό5, 6*set+offset, 4*set+offset);
        addObject(νερό6, 6*set+offset, 5*set+offset);
        addObject(νερό7, 6*set+offset, 6*set+offset);
        addObject(νερό8, 6*set+offset, 7*set+offset);
        addObject(νερό9, 6*set+offset, 8*set+offset);
        addObject(νερό10, 7*set+offset, 0*set+offset);
        addObject(νερό11, 7*set+offset, 1*set+offset);
        addObject(νερό12, 7*set+offset, 2*set+offset);
        addObject(νερό13, 7*set+offset, 3*set+offset);
        addObject(νερό14, 7*set+offset, 4*set+offset);
        addObject(νερό15, 7*set+offset, 5*set+offset);
        addObject(νερό16, 7*set+offset, 6*set+offset);
        addObject(νερό17, 7*set+offset, 7*set+offset);
        addObject(νερό18, 7*set+offset, 8*set+offset);
        addObject(νερό19, 8*set+offset, 0*set+offset);
        addObject(νερό20, 8*set+offset, 1*set+offset);
        addObject(νερό21, 8*set+offset, 2*set+offset);
        addObject(νερό22, 8*set+offset, 3*set+offset);
        addObject(νερό23, 8*set+offset, 4*set+offset);
        addObject(νερό24, 8*set+offset, 5*set+offset);
        addObject(νερό25, 8*set+offset, 6*set+offset);
        addObject(νερό26, 8*set+offset, 7*set+offset);
        addObject(νερό27, 8*set+offset, 8*set+offset);
        addObject(νερό28, 9*set+offset, 0*set+offset);
        addObject(νερό29, 9*set+offset, 1*set+offset);
        addObject(νερό30, 9*set+offset, 2*set+offset);
        addObject(νερό31, 9*set+offset, 3*set+offset);
        addObject(νερό32, 9*set+offset, 4*set+offset);
        addObject(νερό33, 9*set+offset, 5*set+offset);
        addObject(νερό34, 9*set+offset, 6*set+offset);
        addObject(νερό35, 9*set+offset, 7*set+offset);
        addObject(νερό36, 10*set+offset, 0*set+offset);
        addObject(νερό37, 10*set+offset, 1*set+offset);
        addObject(νερό38, 10*set+offset, 2*set+offset);
        addObject(νερό39, 10*set+offset, 3*set+offset);
        addObject(νερό40, 10*set+offset, 4*set+offset);
        addObject(νερό41, 10*set+offset, 5*set+offset);
        addObject(νερό42, 10*set+offset, 6*set+offset);
        addObject(νερό43, 11*set+offset, 0*set+offset);
        addObject(νερό44, 11*set+offset, 1*set+offset);
        addObject(νερό45, 11*set+offset, 2*set+offset);
        addObject(νερό46, 11*set+offset, 3*set+offset);
        addObject(νερό47, 11*set+offset, 4*set+offset);
        addObject(νερό48, 11*set+offset, 5*set+offset);
        addObject(νερό49, 12*set+offset, 0*set+offset);
        addObject(νερό50, 12*set+offset, 1*set+offset);
        addObject(νερό51, 12*set+offset, 2*set+offset);
        addObject(νερό52, 12*set+offset, 3*set+offset);
        addObject(νερό53, 12*set+offset, 4*set+offset);
        addObject(νερό54, 13*set+offset, 0*set+offset);
        addObject(νερό55, 13*set+offset, 1*set+offset);
        addObject(νερό56, 13*set+offset, 2*set+offset);
        addObject(νερό57, 13*set+offset, 3*set+offset);
        addObject(νερό58, 14*set+offset, 0*set+offset);
        addObject(νερό59, 14*set+offset, 1*set+offset);
        addObject(νερό60, 14*set+offset, 2*set+offset);
        addObject(νερό61, 15*set+offset, 0*set+offset);
        addObject(νερό62, 15*set+offset, 1*set+offset);
        // Παίκτης
        addObject(fat, 3*set+offset, 3*set+offset);
        dount = fat.printCount();
        // Στόχος του παίκτη για να τελειώσει το παιχνίδι.
        Στόχος στόχος = new Στόχος();
        addObject(στόχος, 14*set, 8*set);
    }
    public void gameOver()
    {
        GameOver gameover = new GameOver();
        addObject(gameover, getWidth()/2, 400);
        addObject(new ScoreBoard(dount), getWidth()/2, 150);
        Greenfoot.stop();
        return;
    }
}
