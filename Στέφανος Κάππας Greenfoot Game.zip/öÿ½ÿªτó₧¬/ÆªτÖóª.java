import greenfoot.*;
public class Τούβλο extends Block
{
    public void act()
    {
    }
}