import greenfoot.*; 
import java.awt.Graphics;
public class Counter extends Actor
{
    private static final Color textColor = new Color(0, 0, 0);
    private int value = 0;
    private int target = 0;
    private String text;
    private int stringLength;
    public Counter()
    {
        this("");
    }
    public Counter(String prefix)
    {
        text = prefix;
        stringLength = (text.length() + 2) * 10;
        setImage(new GreenfootImage(stringLength, 16));
        GreenfootImage image = getImage();
        image.setColor(textColor);
        updateImage();
    }
    public void increment()
    {
        value++;
        updateImage();
    }
    public int getValue()
    {
        return value;
    }
    private void updateImage()
    {
        GreenfootImage image = getImage();
        image.clear();
        image.drawString(text + value, 1, 12);
    }
}