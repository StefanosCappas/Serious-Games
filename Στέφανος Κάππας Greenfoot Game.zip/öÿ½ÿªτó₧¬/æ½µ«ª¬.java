import greenfoot.*;
public class Στόχος extends Block
{
    public void act()
    {
        Actor h = getOneIntersectingObject(Παίκτης.class);  
        if (h != null)
        {
            Επίπεδο_2 world = (Επίπεδο_2) getWorld();
            world.gameOver();
        }
    }
}