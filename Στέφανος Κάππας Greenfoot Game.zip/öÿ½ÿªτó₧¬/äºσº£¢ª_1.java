import greenfoot.*;
import java.util.List;
import java.util.Stack;
public class Επίπεδο_1 extends World
{
    Counter scoreCounter;
    public Επίπεδο_1()
    {    
        super(1024, 576, 1); 
        prepare();
    }

    private void prepare()
    {
        int set = 64;
        int offset = 32;
        // Παίκτης
        Παίκτης fat = new Παίκτης();
        addObject(fat, 3*set+offset, 3*set+offset);
        // Σπίτι του παίκτη ή αλλιώς αφαιτηρία του παιχνιδιού
        Τούβλο τούβλο1 = new Τούβλο(); 
        Τούβλο τούβλο2 = new Τούβλο(); 
        Τούβλο τούβλο3 = new Τούβλο();
        Τούβλο τούβλο4 = new Τούβλο(); 
        Τούβλο τούβλο5 = new Τούβλο(); 
        Τούβλο τούβλο6 = new Τούβλο(); 
        Τούβλο τούβλο7 = new Τούβλο();
        Τούβλο τούβλο8 = new Τούβλο(); 
        Τούβλο τούβλο9 = new Τούβλο(); 
        Τούβλο τούβλο10 = new Τούβλο();
        Τούβλο τούβλο11 = new Τούβλο();
        Τούβλο τούβλο12 = new Τούβλο(); 
        Τούβλο τούβλο13 = new Τούβλο(); 
        Τούβλο τούβλο14 = new Τούβλο();       
        Τούβλο τούβλο15 = new Τούβλο(); 
        addObject(τούβλο1, 1*set+offset, 1*set+offset);
        addObject(τούβλο2, 1*set+offset, 2*set+offset);
        addObject(τούβλο3, 1*set+offset, 3*set+offset);
        addObject(τούβλο4, 1*set+offset, 4*set+offset);
        addObject(τούβλο5, 1*set+offset, 5*set+offset);
        addObject(τούβλο6, 2*set+offset, 5*set+offset);
        addObject(τούβλο7, 4*set+offset, 5*set+offset);
        addObject(τούβλο8, 5*set+offset, 5*set+offset);
        addObject(τούβλο9, 5*set+offset, 4*set+offset);
        addObject(τούβλο10, 5*set+offset, 3*set+offset);
        addObject(τούβλο11, 5*set+offset, 2*set+offset);
        addObject(τούβλο12, 5*set+offset, 1*set+offset);
        addObject(τούβλο13, 4*set+offset, 1*set+offset);
        addObject(τούβλο14, 3*set+offset, 1*set+offset);
        addObject(τούβλο15, 2*set+offset, 1*set+offset);
        // Φαγητά που τρώει ο παίκτης για να παχύνει
        Φαγητό φαγητό1 = new Φαγητό();
        Φαγητό φαγητό2 = new Φαγητό();
        Φαγητό φαγητό3 = new Φαγητό();
        Φαγητό φαγητό4 = new Φαγητό();
        Φαγητό φαγητό5 = new Φαγητό();
        Φαγητό φαγητό6 = new Φαγητό();
        Φαγητό φαγητό7 = new Φαγητό();
        addObject(φαγητό1, 3*set+offset, 6*set+offset);
        addObject(φαγητό2, 4*set+offset, 6*set+offset);
        addObject(φαγητό3, 5*set+offset, 6*set+offset);
        addObject(φαγητό4, 6*set+offset, 6*set+offset);
        addObject(φαγητό5, 6*set+offset, 5*set+offset);
        addObject(φαγητό6, 6*set+offset, 4*set+offset);
        addObject(φαγητό7, 6*set+offset, 3*set+offset);
        // Στόχος του παίκτη για να τελειώσει το παιχνίδι.
        Στόχος στόχος = new Στόχος();
        addObject(στόχος, 14*set, 8*set);
    }
}