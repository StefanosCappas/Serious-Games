import greenfoot.*;
public class Φαγητό extends Actor
{
    public void act()
    {
    }
}